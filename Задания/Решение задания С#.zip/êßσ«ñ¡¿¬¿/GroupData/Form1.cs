﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace GroupData
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["GroupDataConnectionString"].ConnectionString;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            movingTableAdapter.Connection.ConnectionString = GetConnectionString();
            this.movingTableAdapter.Fill(this.groupDataDataSet.Moving);
        }

        private void ResetDataGridView()
        {
            MainTable.CancelEdit();
            MainTable.Columns.Clear();
            MainTable.DataSource = null;
        }

        private void bGroup_Click(object sender, EventArgs e)
        {
            string sql = String.Empty;
            string GroupItems = String.Empty;

            ResetDataGridView();
            MainTable.AutoGenerateColumns = true;
            if (chbDate.Checked)
            {
                sql = String.Concat(sql,"Date as 'Дата',");
                GroupItems = String.Concat(GroupItems, "Date");
            }

            if (chbOrganization.Checked)
            {
                sql = String.Concat(sql, "Organization as 'Организация', ");
                GroupItems = String.Concat(GroupItems, GroupItems == String.Empty ? String.Empty : ",", "Organization");
            }

            if (chbTown.Checked)
            {
                sql = String.Concat(sql, "Town as 'Город', ");
                GroupItems = String.Concat(GroupItems, GroupItems == String.Empty ? String.Empty : ",", "Town");
            }

            if (chbCountry.Checked)
            {
                sql = String.Concat(sql, "Country as 'Страна', ");
                GroupItems = String.Concat(GroupItems, GroupItems == String.Empty ? String.Empty : ",", "Country");
            }

            if (chbManager.Checked)
            {
                sql = String.Concat(sql,"Manager as 'Менеджер', ");
                GroupItems = String.Concat(GroupItems, GroupItems == String.Empty ? String.Empty : ",", "Manager");
            }



            if (sql != String.Empty)
            {
                string query = String.Concat("Select ", sql, " sum(Qty) as 'Количество', sum(Suma) as 'Сумма' From Moving Group by ", GroupItems, " order by ", GroupItems);
                
                SqlConnection connection = new SqlConnection(GetConnectionString());
                SqlDataAdapter dataadapter = new SqlDataAdapter(query, connection);
                DataTable ds = new DataTable();
                int i = dataadapter.Fill(ds);
                MainTable.DataSource = ds;
            }
            else
            {
                DataTable dt = this.groupDataDataSet.Moving;
                MainTable.DataSource = dt;
                foreach (DataGridViewColumn col in MainTable.Columns)
                {
                    col.HeaderText = dt.Columns[col.HeaderText].Caption;
                }
            }
        }
    }
}
