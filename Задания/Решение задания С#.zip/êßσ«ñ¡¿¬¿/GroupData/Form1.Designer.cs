﻿namespace GroupData
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainTable = new System.Windows.Forms.DataGridView();
            this.chbDate = new System.Windows.Forms.CheckBox();
            this.chbOrganization = new System.Windows.Forms.CheckBox();
            this.chbTown = new System.Windows.Forms.CheckBox();
            this.chbManager = new System.Windows.Forms.CheckBox();
            this.chbCountry = new System.Windows.Forms.CheckBox();
            this.bGroup = new System.Windows.Forms.Button();
            this.movingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupDataDataSet = new GroupData.GroupDataDataSet();
            this.movingTableAdapter = new GroupData.GroupDataDataSetTableAdapters.MovingTableAdapter();
            this.Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Organization = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Town = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.countryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.managerDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sumaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.MainTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupDataDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // MainTable
            // 
            this.MainTable.AllowUserToAddRows = false;
            this.MainTable.AllowUserToDeleteRows = false;
            this.MainTable.AutoGenerateColumns = false;
            this.MainTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.MainTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Date,
            this.Organization,
            this.Town,
            this.countryDataGridViewTextBoxColumn,
            this.managerDataGridViewTextBoxColumn,
            this.qtyDataGridViewTextBoxColumn,
            this.sumaDataGridViewTextBoxColumn});
            this.MainTable.DataSource = this.movingBindingSource;
            this.MainTable.Location = new System.Drawing.Point(0, 35);
            this.MainTable.Name = "MainTable";
            this.MainTable.ReadOnly = true;
            this.MainTable.Size = new System.Drawing.Size(754, 140);
            this.MainTable.TabIndex = 0;
            // 
            // chbDate
            // 
            this.chbDate.AutoSize = true;
            this.chbDate.Location = new System.Drawing.Point(47, 15);
            this.chbDate.Name = "chbDate";
            this.chbDate.Size = new System.Drawing.Size(52, 17);
            this.chbDate.TabIndex = 1;
            this.chbDate.Text = "Дата";
            this.chbDate.UseVisualStyleBackColor = true;
            // 
            // chbOrganization
            // 
            this.chbOrganization.AutoSize = true;
            this.chbOrganization.Location = new System.Drawing.Point(143, 15);
            this.chbOrganization.Name = "chbOrganization";
            this.chbOrganization.Size = new System.Drawing.Size(93, 17);
            this.chbOrganization.TabIndex = 2;
            this.chbOrganization.Text = "Организация";
            this.chbOrganization.UseVisualStyleBackColor = true;
            // 
            // chbTown
            // 
            this.chbTown.AutoSize = true;
            this.chbTown.Location = new System.Drawing.Point(242, 15);
            this.chbTown.Name = "chbTown";
            this.chbTown.Size = new System.Drawing.Size(56, 17);
            this.chbTown.TabIndex = 3;
            this.chbTown.Text = "Город";
            this.chbTown.UseVisualStyleBackColor = true;
            // 
            // chbManager
            // 
            this.chbManager.AutoSize = true;
            this.chbManager.Location = new System.Drawing.Point(443, 15);
            this.chbManager.Name = "chbManager";
            this.chbManager.Size = new System.Drawing.Size(79, 17);
            this.chbManager.TabIndex = 4;
            this.chbManager.Text = "Менеджер";
            this.chbManager.UseVisualStyleBackColor = true;
            // 
            // chbCountry
            // 
            this.chbCountry.AutoSize = true;
            this.chbCountry.Location = new System.Drawing.Point(342, 15);
            this.chbCountry.Name = "chbCountry";
            this.chbCountry.Size = new System.Drawing.Size(62, 17);
            this.chbCountry.TabIndex = 5;
            this.chbCountry.Text = "Страна";
            this.chbCountry.UseVisualStyleBackColor = true;
            // 
            // bGroup
            // 
            this.bGroup.Location = new System.Drawing.Point(656, 8);
            this.bGroup.Name = "bGroup";
            this.bGroup.Size = new System.Drawing.Size(95, 23);
            this.bGroup.TabIndex = 6;
            this.bGroup.Text = "Группировать";
            this.bGroup.UseVisualStyleBackColor = true;
            this.bGroup.Click += new System.EventHandler(this.bGroup_Click);
            // 
            // movingBindingSource
            // 
            this.movingBindingSource.DataMember = "Moving";
            this.movingBindingSource.DataSource = this.groupDataDataSet;
            // 
            // groupDataDataSet
            // 
            this.groupDataDataSet.DataSetName = "GroupDataDataSet";
            this.groupDataDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // movingTableAdapter
            // 
            this.movingTableAdapter.ClearBeforeFill = true;
            // 
            // Date
            // 
            this.Date.DataPropertyName = "Date";
            this.Date.HeaderText = "Дата";
            this.Date.Name = "Date";
            this.Date.ReadOnly = true;
            // 
            // Organization
            // 
            this.Organization.DataPropertyName = "Organization";
            this.Organization.HeaderText = "Организация";
            this.Organization.Name = "Organization";
            this.Organization.ReadOnly = true;
            // 
            // Town
            // 
            this.Town.DataPropertyName = "Town";
            this.Town.HeaderText = "Город";
            this.Town.Name = "Town";
            this.Town.ReadOnly = true;
            // 
            // countryDataGridViewTextBoxColumn
            // 
            this.countryDataGridViewTextBoxColumn.DataPropertyName = "Country";
            this.countryDataGridViewTextBoxColumn.HeaderText = "Страна";
            this.countryDataGridViewTextBoxColumn.Name = "countryDataGridViewTextBoxColumn";
            this.countryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // managerDataGridViewTextBoxColumn
            // 
            this.managerDataGridViewTextBoxColumn.DataPropertyName = "Manager";
            this.managerDataGridViewTextBoxColumn.HeaderText = "Менеджер";
            this.managerDataGridViewTextBoxColumn.Name = "managerDataGridViewTextBoxColumn";
            this.managerDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtyDataGridViewTextBoxColumn
            // 
            this.qtyDataGridViewTextBoxColumn.DataPropertyName = "Qty";
            this.qtyDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.qtyDataGridViewTextBoxColumn.Name = "qtyDataGridViewTextBoxColumn";
            this.qtyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sumaDataGridViewTextBoxColumn
            // 
            this.sumaDataGridViewTextBoxColumn.DataPropertyName = "Suma";
            this.sumaDataGridViewTextBoxColumn.HeaderText = "Сумма";
            this.sumaDataGridViewTextBoxColumn.Name = "sumaDataGridViewTextBoxColumn";
            this.sumaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 182);
            this.Controls.Add(this.bGroup);
            this.Controls.Add(this.chbCountry);
            this.Controls.Add(this.chbManager);
            this.Controls.Add(this.chbTown);
            this.Controls.Add(this.chbOrganization);
            this.Controls.Add(this.chbDate);
            this.Controls.Add(this.MainTable);
            this.Name = "Form1";
            this.Text = "Группировка данных в таблице";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MainTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.movingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupDataDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView MainTable;
        private GroupDataDataSet groupDataDataSet;
        private System.Windows.Forms.BindingSource movingBindingSource;
        private GroupDataDataSetTableAdapters.MovingTableAdapter movingTableAdapter;
        private System.Windows.Forms.CheckBox chbDate;
        private System.Windows.Forms.CheckBox chbOrganization;
        private System.Windows.Forms.CheckBox chbTown;
        private System.Windows.Forms.CheckBox chbManager;
        private System.Windows.Forms.CheckBox chbCountry;
        private System.Windows.Forms.Button bGroup;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Organization;
        private System.Windows.Forms.DataGridViewTextBoxColumn Town;
        private System.Windows.Forms.DataGridViewTextBoxColumn countryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn managerDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sumaDataGridViewTextBoxColumn;
    }
}

